"""Run with your project's Python; dependencies: numpy,pandas,matplotlib."""
from pathlib import Path
import sys,json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from density_panel.panels import plot_panel
OUT=ROOT/'example_outputs';OUT.mkdir(exist_ok=True)
for kind,package,key in [('density','density_panel','histograms'),('boxplot','boxplot_panel','summaries')]:
    data=ROOT/'example'/package
    tables={k:pd.read_csv(data/f'{k}.csv') for k in ['points',key]}
    style=json.loads((data/'figure_spec.json').read_text(encoding='utf-8'))['style']
    with plt.rc_context({'font.family':'Arial','pdf.fonttype':42,'svg.fonttype':'none'}):
        fig,handles=plot_panel(kind,tables,style)
        for ext in ['png','pdf','svg']:
            fig.savefig(OUT/f'{package}.{ext}',dpi=300,facecolor='white')
        plt.close(fig)
print('Two demonstration panels exported. These are graphical estimates, not original observations.')
