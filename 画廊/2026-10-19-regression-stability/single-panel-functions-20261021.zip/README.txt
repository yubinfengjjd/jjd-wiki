Copy density_panel and/or boxplot_panel into your project scripts directory.
Use your project Python environment (numpy,pandas,matplotlib). See per-panel README.
Functions consume result tables; no model training/statistics are performed.
Example data are graphical estimates, not original observations; box x jitter is synthetic.
Gallery/wiki approval remains pending; this ZIP is a portable function delivery, not an approved wiki template.
